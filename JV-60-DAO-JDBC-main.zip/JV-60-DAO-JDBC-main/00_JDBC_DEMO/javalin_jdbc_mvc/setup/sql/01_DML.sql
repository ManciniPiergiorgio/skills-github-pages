
-- Pulisce la tabella prima di inserire i dati di test (opzionale)
-- DELETE FROM public.user_demo_jdbc;

INSERT INTO public.user_demo_jdbc (username, email, user_password, birthdate)
VALUES ('mario_rossi', 'mario.rossi@email.com', 'password1', '1990-05-15');

INSERT INTO public.user_demo_jdbc (username, email, user_password, birthdate)
VALUES ('luigi_verdi', 'luigi.verdi@email.com', 'password2', '1985-08-22');

INSERT INTO public.user_demo_jdbc (username, email, user_password, birthdate)
VALUES ('anna_bianchi', 'anna.bianchi@email.com', 'password3', '1992-12-03');

INSERT INTO public.user_demo_jdbc (username, email, user_password, birthdate)
VALUES ('paolo_neri', 'paolo.neri@email.com', 'password4', '1988-03-10');

INSERT INTO public.user_demo_jdbc (username, email, user_password, birthdate)
VALUES ('giulia_rosa', 'giulia.rosa@email.com', 'password5', '1995-07-28');