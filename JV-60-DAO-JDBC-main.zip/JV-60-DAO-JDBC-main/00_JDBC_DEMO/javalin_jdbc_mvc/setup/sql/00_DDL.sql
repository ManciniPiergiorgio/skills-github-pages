CREATE TABLE IF NOT EXISTS users_demo_jdbc(
	id SERIAL PRIMARY KEY, 
	username VARCHAR(50) NOT NULL UNIQUE, 
	email VARCHAR(100) NOT NULL UNIQUE, 
	user_password VARCHAR(15) NOT NULL, 
	birthdate DATE, 
	created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

	-- vincoli 
	CONSTRAINT chk_username_length CHECK ( LENGTH(username) >= 5), 
	CONSTRAINT chk_email_format CHECK ( email LIKE '%@%' ), 
	CONSTRAINT chk_user_password_length CHECK ( LENGTH(user_password) >= 5 AND LENGTH(user_password) <= 15 ) 
); 

CREATE INDEX IF NOT EXISTS idx_email ON users_demo_jdbc(email); 
CREATE INDEX IF NOT EXISTS idx_username ON users_demo_jdbc(username); 

-- 16/01 FIX: Users dovrebbe essere scritto al singolare (user)
ALTER TABLE IF EXISTS public.users_demo_jdbc RENAME TO user_demo_jdbc;