package com.davidefella.service;

import com.davidefella.model.UserDemoJDBC;
import com.davidefella.repository.UserDemoJDBCDAO;
import com.davidefella.repository.UserDemoJDBCDAOImpl;
import com.davidefella.util.DatabaseConnection;
import org.junit.jupiter.api.*;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Classe di test per UserDemoJDBCService.
 *
 * Questa classe testa tutte le operazioni CRUD del service layer.
 * I test seguono il pattern AAA (Arrange-Act-Assert):
 * - Arrange: preparazione dei dati di test
 * - Act: esecuzione del metodo da testare
 * - Assert: verifica dei risultati
 */
@DisplayName("UserDemoJDBCService - Test")
class UserDemoJDBCServiceTest {

    // Service da testare
    private static UserDemoJDBCService userService;

    // DAO usato per setup/cleanup dei test
    private static UserDemoJDBCDAO userDAO;

    // ID univoco generato per ogni test per evitare conflitti di chiavi primarie
    private String uniqueId;

    /**
     * Metodo eseguito UNA SOLA VOLTA prima di tutti i test.
     * Inizializza la connessione al database e crea le istanze di service e DAO.
     */
    @BeforeAll
    static void initDatabase() {
        // Carica la configurazione del database dal file properties
        DatabaseConnection.init("config.properties");

        // Crea le istanze necessarie per i test
        userService = new UserDemoJDBCService();
        userDAO = new UserDemoJDBCDAOImpl();
    }

    /**
     * Metodo eseguito PRIMA DI OGNI test.
     * Pulisce il database e genera un ID univoco per evitare conflitti.
     */
    @BeforeEach
    void setUp() {
        // Pulisco il database prima di ogni test per evitare conflitti di chiavi
        userDAO.deleteAll();

        // Genero un ID univoco per ogni test (es: "a1b2c3d4")
        // Questo garantisce che username e email siano sempre diversi tra i test
        uniqueId = UUID.randomUUID().toString().substring(0, 8);
    }

    /**
     * Metodo eseguito DOPO OGNI test.
     * Pulisce il database per lasciarlo in uno stato pulito.
     */
    @AfterEach
    void tearDown() {
        // Pulizia dopo ogni test
        userDAO.deleteAll();
    }

    // ==================== CREATE ====================

    /**
     * Testa l'inserimento di un nuovo utente.
     * Verifica che:
     * - L'ID venga generato automaticamente dal database
     * - Il timestamp createdAt venga impostato
     * - I dati inseriti corrispondano a quelli passati
     */
    @Test
    @DisplayName("insertUser - Inserisce un nuovo utente con successo")
    void testInsertUser() {
        // Arrange - Preparo i dati dell'utente da inserire
        String username = "user_" + uniqueId;
        String email = "email_" + uniqueId + "@test.com";
        String password = "password123";
        LocalDate birthdate = LocalDate.of(1990, 5, 15);

        // Act - Eseguo l'inserimento
        UserDemoJDBC created = userService.insertUser(username, email, password, birthdate);

        // Assert - Verifico che l'utente sia stato creato correttamente
        assertNotNull(created.getId(), "L'ID dovrebbe essere generato dal database");
        assertNotNull(created.getCreatedAt(), "Il timestamp dovrebbe essere impostato");
        assertEquals(username, created.getUsername(), "Lo username dovrebbe corrispondere");
        assertEquals(email, created.getEmail(), "L'email dovrebbe corrispondere");
    }

    // ==================== READ ====================

    /**
     * Testa che getAllUsers restituisca una lista vuota quando non ci sono utenti.
     */
    @Test
    @DisplayName("getAllUsers - Restituisce lista vuota se non ci sono utenti")
    void testGetAllUsersEmpty() {
        // Act - Recupero tutti gli utenti (il DB e' vuoto dopo setUp)
        List<UserDemoJDBC> users = userService.getAllUsers();

        // Assert - La lista deve essere vuota
        assertTrue(users.isEmpty(), "La lista dovrebbe essere vuota");
    }

    /**
     * Testa che getAllUsers restituisca tutti gli utenti presenti nel database.
     */
    @Test
    @DisplayName("getAllUsers - Restituisce tutti gli utenti")
    void testGetAllUsers() {
        // Arrange - Inserisco 3 utenti nel database
        userService.insertUser("user1_" + uniqueId, "email1_" + uniqueId + "@test.com", "password", LocalDate.of(1990, 1, 1));
        userService.insertUser("user2_" + uniqueId, "email2_" + uniqueId + "@test.com", "password", LocalDate.of(1990, 1, 1));
        userService.insertUser("user3_" + uniqueId, "email3_" + uniqueId + "@test.com", "password", LocalDate.of(1990, 1, 1));

        // Act - Recupero tutti gli utenti
        List<UserDemoJDBC> users = userService.getAllUsers();

        // Assert - Devono esserci esattamente 3 utenti
        assertEquals(3, users.size(), "Dovrebbero esserci 3 utenti");
    }

    /**
     * Testa la ricerca di un utente tramite ID.
     * Verifica che l'utente trovato abbia gli stessi dati di quello inserito.
     */
    @Test
    @DisplayName("getUserById - Trova utente esistente")
    void testGetUserById() {
        // Arrange - Creo un utente e salvo il suo ID
        UserDemoJDBC created = userService.insertUser("user_" + uniqueId, "email_" + uniqueId + "@test.com", "password", LocalDate.of(1990, 1, 1));

        // Act - Cerco l'utente per ID
        UserDemoJDBC found = userService.getUserById(created.getId());

        // Assert - L'utente trovato deve avere gli stessi dati
        assertEquals(created.getId(), found.getId(), "Gli ID devono corrispondere");
        assertEquals(created.getEmail(), found.getEmail(), "Le email devono corrispondere");
    }

    /**
     * Testa la ricerca di un utente tramite email.
     */
    @Test
    @DisplayName("getUserByEmail - Trova utente esistente")
    void testGetUserByEmail() {
        // Arrange - Creo un utente con una email specifica
        String email = "findme_" + uniqueId + "@test.com";
        userService.insertUser("user_" + uniqueId, email, "password", LocalDate.of(1990, 1, 1));

        // Act - Cerco l'utente per email
        UserDemoJDBC found = userService.getUserByEmail(email);

        // Assert - L'email deve corrispondere
        assertEquals(email, found.getEmail(), "L'email deve corrispondere");
    }

    /**
     * Testa la ricerca di un utente tramite username.
     */
    @Test
    @DisplayName("getUserByUsername - Trova utente esistente")
    void testGetUserByUsername() {
        // Arrange - Creo un utente con uno username specifico
        String username = "finduser_" + uniqueId;
        userService.insertUser(username, "email_" + uniqueId + "@test.com", "password", LocalDate.of(1990, 1, 1));

        // Act - Cerco l'utente per username
        UserDemoJDBC found = userService.getUserByUsername(username);

        // Assert - Lo username deve corrispondere
        assertEquals(username, found.getUsername(), "Lo username deve corrispondere");
    }

    // ==================== UPDATE ====================

    /**
     * Testa l'aggiornamento di un utente esistente.
     * Modifica username, email e password e verifica che le modifiche siano persistite.
     */
    @Test
    @DisplayName("updateUser - Aggiorna utente esistente")
    void testUpdateUser() {
        // Arrange - Creo un utente e poi modifico i suoi dati
        UserDemoJDBC created = userService.insertUser("user_" + uniqueId, "email_" + uniqueId + "@test.com", "password", LocalDate.of(1990, 1, 1));
        created.setUsername("updated_" + uniqueId);
        created.setEmail("updated_" + uniqueId + "@test.com");
        created.setUserPassword("newpassword");

        // Act - Aggiorno l'utente
        UserDemoJDBC updated = userService.updateUser(created);

        // Assert - I dati aggiornati devono corrispondere
        assertEquals("updated_" + uniqueId, updated.getUsername(), "Lo username deve essere aggiornato");
        assertEquals("updated_" + uniqueId + "@test.com", updated.getEmail(), "L'email deve essere aggiornata");
        assertEquals("newpassword", updated.getUserPassword(), "La password deve essere aggiornata");
    }

    // ==================== DELETE ====================

    /**
     * Testa l'eliminazione di un utente tramite ID.
     * Verifica che dopo l'eliminazione il database sia vuoto.
     */
    @Test
    @DisplayName("deleteUserById - Elimina utente esistente")
    void testDeleteUserById() {
        // Arrange - Creo un utente
        UserDemoJDBC created = userService.insertUser("user_" + uniqueId, "email_" + uniqueId + "@test.com", "password", LocalDate.of(1990, 1, 1));
        Integer userId = created.getId();

        // Act - Elimino l'utente per ID
        userService.deleteUserById(userId);

        // Assert - Il database deve essere vuoto
        List<UserDemoJDBC> users = userService.getAllUsers();
        assertTrue(users.isEmpty(), "Non dovrebbero esserci piu' utenti");
    }

    /**
     * Testa l'eliminazione di un utente tramite email.
     */
    @Test
    @DisplayName("deleteUserByEmail - Elimina utente esistente")
    void testDeleteUserByEmail() {
        // Arrange - Creo un utente con una email specifica
        String email = "delete_" + uniqueId + "@test.com";
        userService.insertUser("user_" + uniqueId, email, "password", LocalDate.of(1990, 1, 1));

        // Act - Elimino l'utente per email
        userService.deleteUserByEmail(email);

        // Assert - Il database deve essere vuoto
        List<UserDemoJDBC> users = userService.getAllUsers();
        assertTrue(users.isEmpty(), "Non dovrebbero esserci piu' utenti");
    }

    /**
     * Testa l'eliminazione di un utente tramite username.
     */
    @Test
    @DisplayName("deleteUserByUsername - Elimina utente esistente")
    void testDeleteUserByUsername() {
        // Arrange - Creo un utente con uno username specifico
        String username = "deleteuser_" + uniqueId;
        userService.insertUser(username, "email_" + uniqueId + "@test.com", "password", LocalDate.of(1990, 1, 1));

        // Act - Elimino l'utente per username
        userService.deleteUserByUsername(username);

        // Assert - Il database deve essere vuoto
        List<UserDemoJDBC> users = userService.getAllUsers();
        assertTrue(users.isEmpty(), "Non dovrebbero esserci piu' utenti");
    }

    /**
     * Testa l'eliminazione di tutti gli utenti.
     * Verifica che il metodo restituisca il numero corretto di utenti eliminati
     * e che il database sia effettivamente vuoto.
     */
    @Test
    @DisplayName("deleteAllUsers - Elimina tutti gli utenti")
    void testDeleteAllUsers() {
        // Arrange - Inserisco 3 utenti
        userService.insertUser("user1_" + uniqueId, "email1_" + uniqueId + "@test.com", "password", LocalDate.of(1990, 1, 1));
        userService.insertUser("user2_" + uniqueId, "email2_" + uniqueId + "@test.com", "password", LocalDate.of(1990, 1, 1));
        userService.insertUser("user3_" + uniqueId, "email3_" + uniqueId + "@test.com", "password", LocalDate.of(1990, 1, 1));

        // Act - Elimino tutti gli utenti
        int deleted = userService.deleteAllUsers();

        // Assert - Devono essere stati eliminati 3 utenti e il DB deve essere vuoto
        assertEquals(3, deleted, "Dovrebbero essere stati eliminati 3 utenti");
        assertTrue(userService.getAllUsers().isEmpty(), "Il database dovrebbe essere vuoto");
    }
}
