package com.davidefella.service;

import java.time.LocalDate;
import java.util.List;

import com.davidefella.exception.DuplicateUserException;
import com.davidefella.exception.UserNotFoundException;
import com.davidefella.model.UserDemoJDBC;
import com.davidefella.repository.UserDemoJDBCDAO;
import com.davidefella.repository.UserDemoJDBCDAOImpl;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UserDemoJDBCService {

    // Uso l'interfaccia DAO (non l'implementazione concreta) con Dependency Inversion
    private final UserDemoJDBCDAO userDAO;

    public UserDemoJDBCService() {
        userDAO = new UserDemoJDBCDAOImpl();
    }

    // ==================== CREATE ====================

    public UserDemoJDBC insertUser(String username, String email, String userPassword, LocalDate birthdate) {
        log.info("Tentativo di inserimento utente - Username: {}, Email: {}", username, email);

        UserDemoJDBC user2save = new UserDemoJDBC(username, email, userPassword, birthdate);

        if (userDAO.findByEmail(email).isPresent()) {
            log.warn("Email già esistente: {}", email);
            throw new DuplicateUserException("email", email);
        }

        if (userDAO.findByUsername(username).isPresent()) {
            log.warn("Username già esistente: {}", username);
            throw new DuplicateUserException("username", username);
        }

        return userDAO.create(user2save);
    }

    // ==================== READ ====================

    public List<UserDemoJDBC> getAllUsers() {
        return userDAO.findAll();
    }

    public UserDemoJDBC getUserById(Integer id) {
        return userDAO.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id));
    }

    public UserDemoJDBC getUserByEmail(String email) {
        return userDAO.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException("email", email));
    }

    public UserDemoJDBC getUserByUsername(String username) {
        return userDAO.findByUsername(username)
                .orElseThrow(() -> new UserNotFoundException("username", username));
    }

    // ==================== UPDATE ====================

    public UserDemoJDBC updateUser(UserDemoJDBC user) {

        if (userDAO.findById(user.getId()).isEmpty()) {
            throw new UserNotFoundException(user.getId());
        }

        return userDAO.update(user)
                .orElseThrow(() -> new UserNotFoundException(user.getId()));
    }

    // ==================== DELETE ====================

    public int deleteAllUsers() {
        return userDAO.deleteAll();
    }

    public void deleteUserById(Integer id) {
        if (!userDAO.deleteById(id)) {
            throw new UserNotFoundException(id);
        }
    }

    public void deleteUserByEmail(String email) {
        if (!userDAO.deleteByEmail(email)) {
            throw new UserNotFoundException("email", email);
        }
    }

    public void deleteUserByUsername(String username) {
        if (!userDAO.deleteByUsername(username)) {
            throw new UserNotFoundException("username", username);
        }
    }

}
