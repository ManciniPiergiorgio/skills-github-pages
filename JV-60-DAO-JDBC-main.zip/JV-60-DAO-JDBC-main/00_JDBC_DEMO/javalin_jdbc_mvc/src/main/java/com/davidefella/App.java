package com.davidefella;

import com.davidefella.controller.UserDemoJDBCController;
import com.davidefella.util.DatabaseConnection;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import io.javalin.Javalin;
import io.javalin.json.JavalinJackson;

public class App {

    public static void main(String[] args) {
        DatabaseConnection.init("config.properties");
        System.out.println("Properties inizializzate");

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS); // Per gestire conversioni json data/timestamp 

        Javalin app = Javalin.create(config -> {
            config.jsonMapper(new JavalinJackson(objectMapper, true));
            config.http.defaultContentType = "application/json";
        });

        UserDemoJDBCController userDemoJDBCController = new UserDemoJDBCController();
        userDemoJDBCController.registerRoutes(app);

        app.start(8080); //app è metodo di Javalin

    }
}
