package com.davidefella.repository;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.davidefella.model.UserDemoJDBC;
import com.davidefella.util.DatabaseConnection;
import com.davidefella.util.DateConverter;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UserDemoJDBCDAOImpl implements UserDemoJDBCDAO {

    // ==================== CREATE ====================

    @Override
    public UserDemoJDBC create(UserDemoJDBC user) {
        String sql = "INSERT INTO public.user_demo_jdbc(username, email, user_password, birthdate) VALUES(?, ?, ?, ?) RETURNING id, created_at";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getUserPassword());
            ps.setDate(4, Date.valueOf(user.getBirthdate()));

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    user.setId(rs.getInt("id"));
                    user.setCreatedAt(DateConverter.convertLocalDateTimeFromTimestamp(rs.getTimestamp("created_at")));
                }
            }

        } catch (SQLException ex) {
            log.error("Errore durante la creazione dell'utente: {}", user.getEmail(), ex);
            throw new RuntimeException("SQLException: ", ex);
        }

        log.info("Utente creato con successo - ID: {}, Email: {}", user.getId(), user.getEmail());
        return user;
    }

    // ==================== READ ====================

    @Override
    public List<UserDemoJDBC> findAll() {
        String sql = "SELECT id, username, email, user_password, birthdate, created_at FROM public.user_demo_jdbc";
        List<UserDemoJDBC> users = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                users.add(mapResultSetToUser(rs));
            }

        } catch (SQLException ex) {
            log.error("Errore durante il recupero di tutti gli utenti", ex);
            throw new RuntimeException("SQLException: ", ex);
        }

        log.info("Recuperati {} utenti", users.size());
        return users;
    }

    @Override
    public Optional<UserDemoJDBC> findById(Integer id) {
        String sql = "SELECT id, username, email, user_password, birthdate, created_at FROM public.user_demo_jdbc WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToUser(rs));
                }
            }

        } catch (SQLException ex) {
            log.error("Errore durante la ricerca per ID: {}", id, ex);
            throw new RuntimeException("SQLException: ", ex);
        }

        log.debug("Nessun utente trovato con ID: {}", id);
        return Optional.empty();
    }

    @Override
    public Optional<UserDemoJDBC> findByEmail(String email) {
        String sql = "SELECT id, username, email, user_password, birthdate, created_at FROM public.user_demo_jdbc WHERE email = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToUser(rs));
                }
            }

        } catch (SQLException ex) {
            log.error("Errore durante la ricerca per email: {}", email, ex);
            throw new RuntimeException("SQLException: ", ex);
        }

        log.debug("Nessun utente trovato con email: {}", email);
        return Optional.empty();
    }

    @Override
    public Optional<UserDemoJDBC> findByUsername(String username) {
        String sql = "SELECT id, username, email, user_password, birthdate, created_at FROM public.user_demo_jdbc WHERE username = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToUser(rs));
                }
            }

        } catch (SQLException ex) {
            log.error("Errore durante la ricerca per username: {}", username, ex);
            throw new RuntimeException("SQLException: ", ex);
        }

        log.debug("Nessun utente trovato con username: {}", username);
        return Optional.empty();
    }

    // ==================== UPDATE ====================

    @Override
    public Optional<UserDemoJDBC> update(UserDemoJDBC user) {
        String sql = "UPDATE public.user_demo_jdbc SET username = ?, email = ?, user_password = ?, birthdate = ? WHERE id = ? RETURNING id, username, email, user_password, birthdate, created_at";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getUserPassword());
            ps.setDate(4, Date.valueOf(user.getBirthdate()));
            ps.setInt(5, user.getId());

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToUser(rs));
                }
            }

        } catch (SQLException ex) {
            log.error("Errore durante l'aggiornamento dell'utente ID: {}", user.getId(), ex);
            throw new RuntimeException("SQLException: ", ex);
        }

        log.debug("Nessun utente aggiornato con ID: {}", user.getId());
        return Optional.empty();
    }

    // ==================== DELETE ====================

    @Override
    public int deleteAll() {
        String sql = "DELETE FROM public.user_demo_jdbc";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            int deleted = ps.executeUpdate();
            log.info("Eliminati {} utenti", deleted);
            return deleted;

        } catch (SQLException ex) {
            log.error("Errore durante l'eliminazione di tutti gli utenti", ex);
            throw new RuntimeException("SQLException: ", ex);
        }
    }

    @Override
    public boolean deleteById(Integer id) {
        String sql = "DELETE FROM public.user_demo_jdbc WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                log.info("Utente eliminato con ID: {}", id);
                return true;
            }
            log.debug("Nessun utente eliminato con ID: {}", id);
            return false;

        } catch (SQLException ex) {
            log.error("Errore durante l'eliminazione per ID: {}", id, ex);
            throw new RuntimeException("SQLException: ", ex);
        }
    }

    @Override
    public boolean deleteByEmail(String email) {
        String sql = "DELETE FROM public.user_demo_jdbc WHERE email = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                log.info("Utente eliminato con email: {}", email);
                return true;
            }
            log.debug("Nessun utente eliminato con email: {}", email);
            return false;

        } catch (SQLException ex) {
            log.error("Errore durante l'eliminazione per email: {}", email, ex);
            throw new RuntimeException("SQLException: ", ex);
        }
    }

    @Override
    public boolean deleteByUsername(String username) {
        String sql = "DELETE FROM public.user_demo_jdbc WHERE username = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                log.info("Utente eliminato con username: {}", username);
                return true;
            }
            log.debug("Nessun utente eliminato con username: {}", username);
            return false;

        } catch (SQLException ex) {
            log.error("Errore durante l'eliminazione per username: {}", username, ex);
            throw new RuntimeException("SQLException: ", ex);
        }
    }

    // ==================== UTILITY ====================

    private UserDemoJDBC mapResultSetToUser(ResultSet rs) throws SQLException {
        UserDemoJDBC user = new UserDemoJDBC();
        user.setId(rs.getInt("id"));
        user.setUsername(rs.getString("username"));
        user.setEmail(rs.getString("email"));
        user.setUserPassword(rs.getString("user_password"));
        user.setBirthdate(DateConverter.date2LocalDate(rs.getDate("birthdate")));
        user.setCreatedAt(DateConverter.convertLocalDateTimeFromTimestamp(rs.getTimestamp("created_at")));
        return user;
    }

}
