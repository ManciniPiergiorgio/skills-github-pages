package com.davidefella.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDemoJDBC {

    private Integer id;
    private String username;
    private String email;
    private String userPassword;
    private LocalDate birthdate;
    private LocalDateTime createdAt;

    public UserDemoJDBC(String username, String email, String userPassword, LocalDate birthdate){
        this.username = username; 
        this.email = email; 
        this.userPassword = userPassword; 
        this.birthdate = birthdate; 
    }

}
