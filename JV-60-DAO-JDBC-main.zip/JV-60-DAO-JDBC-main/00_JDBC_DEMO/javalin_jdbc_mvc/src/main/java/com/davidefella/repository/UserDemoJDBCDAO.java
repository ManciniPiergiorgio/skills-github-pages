package com.davidefella.repository;

import java.util.List;
import java.util.Optional;

import com.davidefella.model.UserDemoJDBC;

/**
 * DAO (Data Access Object) Interface per UserDemoJDBC.
 * Definisce il contratto per le operazioni CRUD sul database.
 */
public interface UserDemoJDBCDAO {

    // ==================== CREATE ====================

    UserDemoJDBC create(UserDemoJDBC user);

    // ==================== READ ====================

    List<UserDemoJDBC> findAll();

    Optional<UserDemoJDBC> findById(Integer id);

    Optional<UserDemoJDBC> findByEmail(String email);

    Optional<UserDemoJDBC> findByUsername(String username);

    // ==================== UPDATE ====================

    Optional<UserDemoJDBC> update(UserDemoJDBC user);

    // ==================== DELETE ====================

    int deleteAll();

    boolean deleteById(Integer id);

    boolean deleteByEmail(String email);

    boolean deleteByUsername(String username);

}
