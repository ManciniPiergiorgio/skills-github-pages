const BASE_URL = "http://localhost:8080/api/v1/users";

// CREATE
export async function createUser(user) {
  const response = await fetch(BASE_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(user)
  });

  if (!response.ok) {
    throw new Error("Errore nella creazione utente");
  }

  return response.json();
}

// READ - tutti gli utenti
export async function getAllUsers() {
  const response = await fetch(BASE_URL);

  if (!response.ok) {
    throw new Error("Errore nel recupero utenti");
  }

  return response.json();
}

// READ - per ID
export async function getUserById(id) {
  const response = await fetch(`${BASE_URL}/${id}`);

  if (!response.ok) {
    throw new Error("Utente non trovato");
  }

  return response.json();
}

// READ - per email
export async function getUserByEmail(email) {
  const response = await fetch(`${BASE_URL}/email/${email}`);

  if (!response.ok) {
    throw new Error("Utente non trovato");
  }

  return response.json();
}

// READ - per username
export async function getUserByUsername(username) {
  const response = await fetch(`${BASE_URL}/username/${username}`);

  if (!response.ok) {
    throw new Error("Utente non trovato");
  }

  return response.json();
}

// UPDATE
export async function updateUser(id, user) {
  const response = await fetch(`${BASE_URL}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(user)
  });

  if (!response.ok) {
    throw new Error("Errore nell'aggiornamento utente");
  }

  return response.json();
}

// DELETE - per ID
export async function deleteUserById(id) {
  const response = await fetch(`${BASE_URL}/${id}`, {
    method: "DELETE"
  });

  if (!response.ok) {
    throw new Error("Errore nella cancellazione utente");
  }

  return response.json();
}

// DELETE - tutti
export async function deleteAllUsers() {
  const response = await fetch(BASE_URL, {
    method: "DELETE"
  });

  if (!response.ok) {
    throw new Error("Errore nella cancellazione di tutti gli utenti");
  }

  return response.json();
}

// DELETE - per email
export async function deleteUserByEmail(email) {
  const response = await fetch(`${BASE_URL}/email/${email}`, {
    method: "DELETE"
  });

  if (!response.ok) {
    throw new Error("Errore nella cancellazione utente");
  }

  return response.json();
}

// DELETE - per username
export async function deleteUserByUsername(username) {
  const response = await fetch(`${BASE_URL}/username/${username}`, {
    method: "DELETE"
  });

  if (!response.ok) {
    throw new Error("Errore nella cancellazione utente");
  }

  return response.json();
}
